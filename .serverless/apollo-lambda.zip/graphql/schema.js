"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.schema = void 0;
const nexus_1 = require("nexus");
const nexus_prisma_1 = require("nexus-prisma");
const src_1 = require("src");
const Address = (0, nexus_1.objectType)({
    name: nexus_prisma_1.address.$name,
    description: nexus_prisma_1.individual.$description,
    definition(t) {
        t.field(nexus_prisma_1.address.addressid);
        t.field(nexus_prisma_1.address.individualid);
        t.field(nexus_prisma_1.address.line1);
        t.field(nexus_prisma_1.address.city);
        t.field(nexus_prisma_1.address.zip);
    }
});
// const AddressTypes = enumType({
//   name: 'Episode',
//   members: {
//     NEWHOPE: 4,
//     EMPIRE: 5,
//     JEDI: 6,
//   },
// })
const Individual = (0, nexus_1.objectType)({
    name: nexus_prisma_1.individual.$name,
    description: nexus_prisma_1.individual.$description,
    definition(t) {
        t.field(nexus_prisma_1.individual.individualid);
        t.field(nexus_prisma_1.individual.firstname);
        t.field(nexus_prisma_1.individual.lastname);
        t.field(nexus_prisma_1.individual.email);
    }
});
const IndividualsQuery = (0, nexus_1.queryType)({
    definition(t) {
        t.list.field('fetchIndividuals', {
            type: nexus_prisma_1.individual.$name,
            resolve: () => {
                return src_1.prisma.individual.findMany();
            },
        });
    }
});
const schema = (0, nexus_1.makeSchema)({
    types: {
        Address,
        Individual,
        IndividualsQuery
    },
    outputs: {
        schema: __dirname + "/generated/schema.graphql",
        typegen: __dirname + "/generated/nexus.ts",
    },
});
exports.schema = schema;
//# sourceMappingURL=schema.js.map