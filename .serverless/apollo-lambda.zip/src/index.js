"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.graphqlHandler = exports.prisma = void 0;
const server_1 = require("@apollo/server");
const client_1 = require("@prisma/client");
const aws_lambda_1 = require("@as-integrations/aws-lambda");
const schema_1 = require("../graphql/schema");
exports.prisma = new client_1.PrismaClient();
const server = new server_1.ApolloServer({
    schema: schema_1.schema,
    introspection: true,
});
exports.graphqlHandler = (0, aws_lambda_1.startServerAndCreateLambdaHandler)(server, {
    context: async () => exports.prisma
});
//# sourceMappingURL=index.js.map